const express = require('express');
const path = require('path');
const fs = require('fs');
const QuestManager = require('../quests/manager'); // Import QuestManager
const app = express();

// For custom file uploads (catbox.moe hosting) — fall back to Node globals
// (Node 18+ has FormData, Blob and fetch built in via undici)
let _undici = null;
try { _undici = require('undici'); } catch (_) { /* not installed, use globals */ }
const FormData = (_undici && _undici.FormData) || global.FormData;
const Blob = (_undici && _undici.Blob) || global.Blob;
const fetch = (_undici && _undici.fetch) || global.fetch;

module.exports = (client) => {
    const port = process.env.PORT || 3000;

    // Initialize Quest Manager
    const questManager = new QuestManager(process.env.TOKEN || client.token);

    // Set view engine
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, 'views'));

    // Static files
    app.use(express.static(path.join(__dirname, 'public')));
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json()); // Add JSON body parser for AJAX
    const cookieParser = require('cookie-parser');
    app.use(cookieParser());

    // --- LOGIN SYSTEM START ---
    const failedLoginAttempts = new Map();

    // Login Page
    app.get('/login', (req, res) => {
        if (req.cookies.auth_token === 'valid_session') {
            return res.redirect('/');
        }
        res.render('login');
    });

    // Login API
    app.post('/api/login', async (req, res) => {
        const { username, password } = req.body;
        const ip = req.ip;

        console.log(`[Login Debug] Attempt from ${ip}`);
        console.log(`[Login Debug] Input -> User: '${username}'`);

        // Check Rate Limit
        const record = failedLoginAttempts.get(ip);
        if (record && record.blockedUntil > Date.now()) {
            const remaining = Math.ceil((record.blockedUntil - Date.now()) / 1000 / 60);
            return res.json({ success: false, error: `Too many attempts. Blocked for ${remaining} mins.` });
        }

        // Credentials Check
        const envUser = process.env.APP_USER;
        const envPass = process.env.APP_PASS;

        console.log(`[Login Debug] Config -> AppUser: '${envUser}', AppPass Configured: ${!!envPass}`);

        if (!envUser || !envPass) {
            console.log('[Login Debug] Missing .env config (APP_USER/APP_PASS)');
            return res.json({ success: false, error: 'Login setup missing in .env (APP_USER/APP_PASS).' });
        }

        let failed = false;
        let reason = '';

        if (username !== envUser || password !== envPass) {
            failed = true;
            reason = 'Credentials mismatch';
            console.log(`[Login Debug] Credentials mismatch. Expected User: '${envUser}'`);
        }

        if (failed) {
            const r = record || { count: 0, blockedUntil: 0 };
            r.count++;
            console.log(`[Login Debug] Failed attempt #${r.count}. Reason: ${reason}`);
            if (r.count >= 3) {
                r.blockedUntil = Date.now() + 5 * 60 * 1000; // 5 mins
                r.count = 0;
            }
            failedLoginAttempts.set(ip, r);
            return res.json({ success: false, error: 'Invalid Credentials.' });
        }

        // Success
        console.log('[Login Debug] Success!');
        failedLoginAttempts.delete(ip);

        // Long-lived cookie
        res.cookie('auth_token', 'valid_session', { maxAge: 365 * 24 * 60 * 60 * 1000, httpOnly: true });
        res.json({ success: true });
    });

    // Auth Middleware (Protects everything below)
    app.use((req, res, next) => {
        if (req.path === '/login' || req.path === '/api/login' || req.path.startsWith('/css') || req.path.startsWith('/js') || req.path.startsWith('/images')) {
            return next();
        }
        // Check for cookie
        if (req.cookies.auth_token === 'valid_session') {
            return next();
        }
        res.redirect('/login');
    });
    // --- LOGIN SYSTEM END ---

    app.get('/logout', (req, res) => {
        res.clearCookie('auth_token');
        res.redirect('/login');
    });

    app.get('/', (req, res) => {
        if (!client.user) {
            return res.send('Bot is not ready yet. Please refresh in a moment.');
        }

        // Calculate initial uptime in seconds
        const uptimeSeconds = Math.floor(client.uptime / 1000);

        // Load persisted status data
        const statusManager = require('../commands/statusManager');
        const statusData = statusManager.loadData();

        // Use persisted data, falling back to defaults if necessary
        const status = statusData.status || 'online';
        const currentActivity = statusData.custom_status || '';
        const currentEmoji = statusData.emoji || '';

        res.render('index', {
            user: client.user,
            uptimeSeconds,
            status: status,
            currentActivity,
            currentEmoji,
            page: 'home'
        });
    });

    app.post('/update-status', async (req, res) => {
        try {
            const { status, custom_status, emoji } = req.body;

            const statusManager = require('../commands/statusManager');
            statusManager.saveData({
                status: status,
                custom_status: custom_status,
                emoji: emoji
            });

            // Trigger update via RPC Manager (which merges RPC + Status)
            const rpcManager = require('../commands/rpcManager');
            await rpcManager.setPresence(client, rpcManager.loadData());

            if (req.xhr || req.headers.accept && req.headers.accept.indexOf('json') > -1) {
                return res.json({ success: true, message: 'Status updated!' });
            }

            res.redirect('/');
        } catch (error) {
            console.error(error);
            res.redirect('/?error=' + encodeURIComponent(error.message));
        }
    });

    // --- API & Routes ---

    // Live Logs Endpoint
    app.get('/api/logs', (req, res) => {
        const logPath = path.join(__dirname, '..', 'data', 'afklog.json');
        if (fs.existsSync(logPath)) {
            const logs = JSON.parse(fs.readFileSync(logPath, 'utf8'));
            res.json(logs);
        } else {
            res.json([]);
        }
    });

    // --- QUEST ROUTES ---

    app.get('/quest', (req, res) => {
        if (!client.user) return res.send('Bot loading...');
        res.render('quest', {
            user: client.user,
            page: 'quest'
        });
    });

    app.get('/spammer', (req, res) => {
        if (!client.user) return res.send('Bot loading...');
        res.render('spammer', {
            user: client.user,
            page: 'spammer'
        });
    });

    app.post('/quest/start-all', (req, res) => {
        questManager.startAll(); // Async background
        res.json({ success: true, message: 'Starting process...' });
    });

    app.post('/quest/stop-all', (req, res) => {
        questManager.stopAll();
        res.json({ success: true, message: 'All quests stopped.' });
    });

    app.post('/quest/clear-logs', (req, res) => {
        if (questManager.clearLogs) questManager.clearLogs();
        res.json({ success: true });
    });

    // Bounties — runs the same completion flow as Start All but logs it as
    // "Bounties" so the user can explicitly trigger quest + bounty completion.
    app.post('/quest/start-bounties', (req, res) => {
        questManager.log('system', 'Starting BOUNTIES protocol — completing quests AND bounties...');
        questManager.startAll();
        res.json({ success: true, message: 'Starting bounties + quests completion...' });
    });

    app.get('/api/quests', (req, res) => {
        res.json({
            // active: ... (optional, if we want visuals later)
            logs: questManager.globalLogs,
            isRunning: questManager.isRunning
        });
    });

    // --- AFK Routes ---

    app.get('/afk', (req, res) => {
        if (!client.user) return res.send('Bot loading...');

        const afkPath = path.join(__dirname, '..', 'data', 'afk.json');
        const logPath = path.join(__dirname, '..', 'data', 'afklog.json');

        let afkData = { isOn: false, reason: '' };
        let logs = [];

        if (fs.existsSync(afkPath)) afkData = JSON.parse(fs.readFileSync(afkPath, 'utf8'));
        if (fs.existsSync(logPath)) logs = JSON.parse(fs.readFileSync(logPath, 'utf8'));

        res.render('afk', {
            user: client.user,
            afkData,
            logs,
            page: 'afk'
        });
    });

    app.post('/afk/save', (req, res) => {
        let { isOn, reason, logsEnabled } = req.body;
        const afkPath = path.join(__dirname, '..', 'data', 'afk.json');

        const checkBoolean = (val) => {
            if (Array.isArray(val)) return val.includes('on');
            return val === 'on';
        };

        const isAfkOn = checkBoolean(isOn);
        const isLogsOn = checkBoolean(logsEnabled);

        let existingData = {};
        if (fs.existsSync(afkPath)) existingData = JSON.parse(fs.readFileSync(afkPath, 'utf8'));

        const newData = {
            ...existingData,
            isOn: isAfkOn,
            reason: reason || existingData.reason || 'I am currently AFK.',
            logsEnabled: isLogsOn,
            startTime: isAfkOn ? Date.now() : (existingData.startTime || 0)
        };

        fs.writeFileSync(afkPath, JSON.stringify(newData, null, 2));

        if (req.xhr || req.headers.accept && req.headers.accept.indexOf('json') > -1) {
            return res.json({ success: true, message: 'Settings saved!' });
        }

        res.redirect('/afk');
    });

    app.post('/afk/clear-logs', (req, res) => {
        const { logId, clearAll } = req.body;
        const logPath = path.join(__dirname, '..', 'data', 'afklog.json');

        if (clearAll) {
            fs.writeFileSync(logPath, JSON.stringify([], null, 2));
        } else if (logId) {
            let logs = JSON.parse(fs.readFileSync(logPath, 'utf8'));
            logs = logs.filter(l => l.id !== logId);
            fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
        }

        res.redirect('/afk');
    });

    // --- COMMANDS Routes ---
    app.get('/commands', (req, res) => {
        if (!client.user) return res.send('Bot loading...');
        res.render('commands', {
            user: client.user,
            page: 'commands'
        });
    });

    app.get('/commands/rpc', (req, res) => {
        res.render('cmd_rpc', { user: client.user, page: 'commands' });
    });

    // RPC API
    app.get('/api/rpc', (req, res) => {
        const rpcManager = require('../commands/rpcManager');
        res.json(rpcManager.loadData());
    });

    app.post('/api/rpc', async (req, res) => {
        const rpcManager = require('../commands/rpcManager');
        const data = req.body;
        rpcManager.saveData(data);
        await rpcManager.setPresence(client, data);
        res.json({ success: true });
    });

    // Auto Reaction API
    app.get('/api/reaction', (req, res) => {
        const reactionManager = require('../commands/reactionManager');
        const data = reactionManager.loadData();

        // Enrich Servers
        const enrichedServers = (data.enabledServers || []).map(id => {
            const g = client.guilds.cache.get(id);
            return {
                id,
                name: g ? g.name : `Unknown Server`,
                icon: g ? g.iconURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png'
            };
        });

        // Enrich Channels
        const enrichedChannels = (data.enabledChannels || []).map(id => {
            const c = client.channels.cache.get(id);
            return {
                id,
                name: c ? c.name : `Unknown Channel`,
                guildName: c?.guild ? c.guild.name : 'Unknown Server',
                guildIcon: c?.guild ? c.guild.iconURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png'
            };
        });

        res.json({ ...data, enrichedServers, enrichedChannels });
    });

    app.post('/api/reaction', (req, res) => {
        const reactionManager = require('../commands/reactionManager');
        reactionManager.saveData(req.body);
        res.json({ success: true });
    });

    // Validation APIs
    app.post('/api/validate/guild', async (req, res) => {
        const { id } = req.body;
        try {
            const guild = client.guilds.cache.get(id);
            if (!guild) return res.status(404).json({ error: 'Server not found (Bot must be in it)' });
            res.json({
                id: guild.id,
                name: guild.name,
                icon: guild.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png'
            });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/validate/channel', async (req, res) => {
        const { id } = req.body;
        try {
            const channel = client.channels.cache.get(id);
            if (!channel) return res.status(404).json({ error: 'Channel not found' });
            res.json({
                id: channel.id,
                name: channel.name,
                guildId: channel.guild?.id,
                guildName: channel.guild?.name || 'Direct Message',
                guildIcon: channel.guild?.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png'
            });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // --- AI Chat Routes ---
    app.get('/ai', (req, res) => {
        res.render('cmd_ai', { user: client.user, page: 'ai' }); // page 'ai' for highlighting if added to menu
    });

    app.get('/api/ai', (req, res) => {
        const aiManager = require('../commands/aiManager');
        const data = aiManager.loadData();

        // Enrich Data for UI (Server/Channel/User names)
        // Similar to Reaction, we want to show nice lists

        const enrichedServers = (data.enabledServers || []).map(id => {
            const g = client.guilds.cache.get(id);
            return { id, name: g ? g.name : 'Unknown Server', icon: g ? g.iconURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png' };
        });
        const enrichedChannels = (data.enabledChannels || []).map(id => {
            const c = client.channels.cache.get(id);
            return { id, name: c ? c.name : 'Unknown Channel', guildName: c?.guild?.name || 'Unknown', guildIcon: c?.guild?.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png' };
        });
        const enrichedGroupsAlways = (data.enabledGroups || []).map(id => {
            const c = client.channels.cache.get(id);
            let name = c ? c.name : 'Unknown Channel/Group';
            if (c && !name && c.recipients) name = c.recipients.map(u => u.username).join(', ');
            return { id, name, mode: 'always' };
        });
        const enrichedGroupsMention = (data.enabledGroupsMention || []).map(id => {
            const c = client.channels.cache.get(id);
            let name = c ? c.name : 'Unknown Channel/Group';
            if (c && !name && c.recipients) name = c.recipients.map(u => u.username).join(', ');
            return { id, name, mode: 'mention' };
        });
        const enrichedGroups = [...enrichedGroupsAlways, ...enrichedGroupsMention];

        const enrichedFreeWill = (data.freeWillChannels || []).map(item => {
            const id = typeof item === 'object' ? item.id : item;
            const delay = typeof item === 'object' ? item.delay : 0;
            const c = client.channels.cache.get(id);
            return { id, delay, name: c ? c.name : 'Unknown Channel', guildName: c?.guild?.name || 'Unknown', guildIcon: c?.guild?.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png' };
        });
        const enrichedUsers = (data.dmUsers || []).map(id => {
            const u = client.users.cache.get(id); // Users might not be cached if not seen?
            // Selfbots usually have large cache if they are in servers.
            return { id, username: u ? u.username : 'Unknown User', avatar: u ? u.displayAvatarURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png' };
        });

        const enrichedBlockedUsers = (data.blockedUsers || []).map(id => {
            const u = client.users.cache.get(id);
            return { id, username: u ? u.username : 'Unknown User', avatar: u ? u.displayAvatarURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png' };
        });

        res.json({ ...data, enrichedServers, enrichedChannels, enrichedGroups, enrichedFreeWill, enrichedUsers, enrichedBlockedUsers });
    });

    app.post('/api/ai', (req, res) => {
        const aiManager = require('../commands/aiManager');
        aiManager.saveData(req.body);
        res.json({ success: true });
    });

    app.post('/api/validate/user', async (req, res) => {
        const { id } = req.body;
        try {
            const user = await client.users.fetch(id).catch(() => null);
            if (!user) return res.status(404).json({ error: 'User not found' });
            res.json({
                id: user.id,
                username: user.username,
                avatar: user.displayAvatarURL({ dynamic: true })
            });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Validate Channel OR User (Mixed) for Auto Msg
    app.post('/api/validate/mixed', async (req, res) => {
        const { id } = req.body;
        try {
            // Check Channel First
            const channel = await client.channels.fetch(id).catch(() => null);
            if (channel) {
                // Must be text-based to send messages
                if (!channel.isText()) return res.status(400).json({ error: 'Channel is not a text channel' });
                return res.json({
                    type: 'channel',
                    id: channel.id,
                    name: channel.name,
                    guildName: channel.guild?.name || 'DM',
                    icon: channel.guild?.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png'
                });
            }

            // Check User Second
            const user = await client.users.fetch(id).catch(() => null);
            if (user) {
                return res.json({
                    type: 'user',
                    id: user.id,
                    name: user.username,
                    guildName: 'Direct Message', // Display context as DM for clarity
                    icon: user.displayAvatarURL({ dynamic: true })
                });
            }

            res.status(404).json({ error: 'ID not found (Must be Channel or User)' });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/commands/reaction', (req, res) => {
        res.render('cmd_reaction', { user: client.user, page: 'commands' });
    });
    app.get('/commands/mirror', (req, res) => {
        res.render('cmd_mirror', { user: client.user, page: 'commands' });
    });
    app.get('/commands/clipboard', (req, res) => {
        res.render('cmd_clipboard', { user: client.user, page: 'commands' });
    });

    // --- Auto Msg Routes ---
    app.get('/commands/auto-msg', (req, res) => {
        res.render('cmd_auto_msg', { user: client.user, page: 'commands' });
    });

    app.get('/api/auto-msg', (req, res) => {
        const autoMsg = require('../commands/autoMsg');
        res.json(autoMsg.getList());
    });

    app.post('/api/auto-msg', async (req, res) => {
        const autoMsg = require('../commands/autoMsg');
        const { action, channelId, message, interval, unit } = req.body;

        try {
            if (action === 'add') {
                // Validate permissions one last time logic?
                // The frontend checks, but backend should too ideally.
                // startTimer throws if invalid.
                await autoMsg.startTimer(client, channelId, message, interval, unit);
                autoMsg.addAutoMsg(channelId, message, interval, unit); // Save if start success
            } else if (action === 'remove') {
                autoMsg.removeAutoMsg(channelId);
            }
            res.json({ success: true });
        } catch (e) {
            res.status(400).json({ error: e.message });
        }
    });

    // --- Timed Msg Routes ---
    app.get('/commands/timed-msg', (req, res) => {
        res.render('cmd_timed_msg', { user: client.user, page: 'commands' });
    });

    app.get('/api/timed-msg', (req, res) => {
        const timedMsg = require('../commands/timedMsg');
        res.json(timedMsg.getList());
    });

    app.post('/api/timed-msg', async (req, res) => {
        const timedMsg = require('../commands/timedMsg');
        const { action, id, channelId, message, timestamp, timezone } = req.body;

        try {
            if (action === 'add') {
                const item = timedMsg.addTimedMsg(client, channelId, message, timestamp, timezone);
                res.json({ success: true, item });
            } else if (action === 'remove') {
                timedMsg.removeTimedMsg(id);
                res.json({ success: true });
            } else {
                res.status(400).json({ error: 'Invalid action' });
            }
        } catch (e) {
            res.status(400).json({ error: e.message });
        }
    });

    app.get('/api/clipboard', (req, res) => {
        const clipboardManager = require('../commands/clipboardManager');
        res.json(clipboardManager.loadData());
    });

    app.post('/api/clipboard', (req, res) => {
        const clipboardManager = require('../commands/clipboardManager');
        const { action, trigger, response } = req.body;

        if (action === 'add') {
            clipboardManager.addTrigger(trigger, response);
        } else if (action === 'remove') {
            clipboardManager.removeTrigger(trigger);
        }
        res.json({ success: true });
    });

    app.get('/commands/allowed', (req, res) => {
        res.render('cmd_allowed', { user: client.user, page: 'commands' });
    });

    // --- Allowed ID Routes ---
    app.get('/api/allowed', async (req, res) => {
        const allowedManager = require('../commands/allowedManager');
        const data = allowedManager.loadData();

        // Enrich user data
        const enrichedUsers = await Promise.all(data.allowedUsers.map(async (id) => {
            const u = await client.users.fetch(id).catch(() => null);
            return {
                id,
                username: u ? u.username : 'Unknown User',
                avatar: u ? u.displayAvatarURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png'
            };
        }));

        res.json({ allowedUsers: enrichedUsers });
    });

    app.post('/api/allowed', (req, res) => {
        const { action, id } = req.body;
        const allowedManager = require('../commands/allowedManager');

        if (action === 'add') {
            allowedManager.addAllowedUser(id);
        } else if (action === 'remove') {
            allowedManager.removeAllowedUser(id);
        }
        res.json({ success: true });
    });

    // --- Mirror Routes ---
    app.get('/api/mirror', (req, res) => {
        const mirrorManager = require('../commands/mirrorManager');
        const list = mirrorManager.getActiveMirrors() || [];
        const enriched = list.map(m => {
            const s = client.channels.cache.get(m.sourceId);
            const t = client.channels.cache.get(m.targetId);
            return {
                ...m,
                sourceName: s ? `#${s.name} (${s.guild?.name || 'DM'})` : m.sourceId,
                targetName: t ? `#${t.name} (${t.guild?.name || 'DM'})` : m.targetId,
                sourceIcon: s?.guild?.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png',
                targetIcon: t?.guild?.iconURL({ dynamic: true }) || 'https://cdn.discordapp.com/embed/avatars/0.png'
            };
        });
        res.json(enriched);
    });

    app.post('/api/mirror', async (req, res) => {
        const { sourceId, targetId, mode } = req.body;
        const mirrorManager = require('../commands/mirrorManager');
        try {
            await mirrorManager.startMirror(client, sourceId, targetId, mode);
            res.json({ success: true });
        } catch (e) {
            res.status(400).json({ error: e.message });
        }
    });

    app.delete('/api/mirror', async (req, res) => {
        const { sourceId } = req.body;
        const mirrorManager = require('../commands/mirrorManager');
        await mirrorManager.stopMirror(sourceId);
        res.json({ success: true });
    });

    app.post('/api/validate/mirror-channel', async (req, res) => {
        const { id, checkWebhook } = req.body;
        try {
            const channel = await client.channels.fetch(id).catch(() => null);
            if (!channel) return res.status(404).json({ error: 'Channel not found/Not Visible' });

            if (!channel.isText()) return res.status(400).json({ error: 'Not a text channel' });

            // Selfbots have full user perms, just check if we can view/send
            // But channel.permissionsFor works if in guild.
            if (channel.guild) {
                const permissions = channel.permissionsFor(client.user);

                // If checking Target, ensure we can SEND
                const { type } = req.body;
                if (type === 'target') {
                    if (!permissions.has('SEND_MESSAGES')) return res.status(403).json({ error: 'Missing SEND_MESSAGES permission' });
                } else {
                    // Source: just need to view
                    if (!permissions.has('VIEW_CHANNEL')) return res.status(403).json({ error: 'Missing VIEW_CHANNEL permission' });
                }

                if (checkWebhook) {
                    if (!permissions.has('MANAGE_WEBHOOKS')) return res.status(403).json({ error: 'Missing MANAGE_WEBHOOKS permission (Required for Clone)' });
                }
            } else {
                // DM - always can send if friend?
                // Webhooks don't work in DMs.
                if (checkWebhook) return res.status(400).json({ error: 'Clone Mode (Webhooks) not supported in DMs' });
            }

            res.json({
                success: true,
                name: channel.name || 'DM',
                guildName: channel.guild?.name || 'Direct Message',
                icon: channel.guild?.iconURL({ dynamic: true }) || channel.recipient?.displayAvatarURL({ dynamic: true })
            });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/commands/welcomer', (req, res) => {
        res.render('cmd_welcomer', { user: client.user, page: 'commands' });
    });

    app.get('/api/welcomer', async (req, res) => {
        const welcomerManager = require('../commands/welcomerManager');
        const data = welcomerManager.loadData();
        const setups = data.welcomeSetups || {};

        // Enrich server info
        const enrichedList = [];
        for (const [guildId, val] of Object.entries(setups)) {
            const guild = client.guilds.cache.get(guildId);
            let channelName = "Unknown Channel";
            if (guild) {
                const c = guild.channels.cache.get(val.channelId);
                if (c) channelName = c.name;
            }

            enrichedList.push({
                guildId,
                guildName: guild ? guild.name : `Server ${guildId}`,
                icon: guild && guild.iconURL() ? guild.iconURL({ dynamic: true }) : 'https://cdn.discordapp.com/embed/avatars/0.png',
                channelId: val.channelId,
                channelName: channelName,
                template: val.template,
                background: val.background,
                textcolor: val.textcolor,
                welcomeType: val.welcomeType || 'card',
                textMessage: val.textMessage || 'hey {user} welcome to the {server} you are {count} member',
                cardMessage: val.cardMessage || 'WELCOME TO {server}\n{user}\nMember #{count}'
            });
        }
        const config = data.config || { textcolor: 'white', welcomeType: 'card', textMessage: 'hey {user} welcome to the {server} you are {count} member', cardMessage: 'WELCOME TO {server}\n{user}\nMember #{count}' };
        res.json({ setups: enrichedList, config });
    });

    app.post('/api/welcomer', (req, res) => {
        const welcomerManager = require('../commands/welcomerManager');
        const { action, guildId, channelId, template, background, textcolor, welcomeType, textMessage, cardMessage } = req.body;

        try {
            if (action === 'add') {
                welcomerManager.addSetup(guildId, channelId, template, background, textcolor, welcomeType, textMessage, cardMessage);
            } else if (action === 'remove') {
                welcomerManager.removeSetup(guildId);
            } else if (action === 'saveConfig') {
                const data = welcomerManager.loadData();
                data.config = { textcolor, welcomeType, textMessage, cardMessage };
                
                // Update all existing setups automatically
                if (!data.welcomeSetups) data.welcomeSetups = {};
                for (let gid of Object.keys(data.welcomeSetups)) {
                    data.welcomeSetups[gid].textcolor = textcolor;
                    data.welcomeSetups[gid].welcomeType = welcomeType;
                    data.welcomeSetups[gid].textMessage = textMessage;
                    data.welcomeSetups[gid].cardMessage = cardMessage;
                }
                welcomerManager.saveData(data);
            }
            res.json({ success: true });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    app.get('/commands/:category', (req, res) => {
        const category = req.params.category;
        res.render('commands_sub', {
            user: client.user,
            page: 'commands',
            category: category.charAt(0).toUpperCase() + category.slice(1)
        });
    });

    // --- MUSIC Routes ---

    app.get('/music', (req, res) => {
        if (!client.user) return res.send('Bot loading...');
        res.render('music', {
            user: client.user,
            page: 'music'
        });
    });

    app.get('/api/music/status', (req, res) => {
        const queues = client.queueManager ? client.queueManager.getAll() : new Map();

        const getCover = (info) => {
            if (info.sourceName === 'youtube' || info.uri.includes('youtube')) {
                return `https://img.youtube.com/vi/${info.identifier}/maxresdefault.jpg`;
            } else if (info.artworkUrl) {
                return info.artworkUrl;
            }
            return 'https://i.imgur.com/2ce2t5e.png';
        };

        let musicData = {
            connected: !!client.lavalink,
            isPlaying: false,
            guildName: 'No Guild',
            guildIcon: null,
            channelName: '',
            nowPlaying: null,
            position: 0,
            duration: 0,
            volume: 100,
            loop: 'none',
            repeatMode: 'once',
            repeatCount: 1,
            currentRepeat: 0,
            autoplay: false,
            queue: [],
            queueCount: 0
        };

        // Get first active queue
        for (const [guildId, queue] of queues) {
            if (queue.nowPlaying) {
                const guild = client.guilds.cache.get(guildId);
                const voiceState = client.lavalinkVoiceStates ? client.lavalinkVoiceStates[guildId] : null; // Custom voiceStates storage
                // OR check client.guilds.cache.get(guildId).me.voice.channel

                musicData.activeGuildId = guildId;
                musicData.isPlaying = true;
                musicData.guildName = guild ? guild.name : `Guild ${guildId}`;
                musicData.guildIcon = guild ? guild.iconURL({ dynamic: true, size: 128 }) : null;
                musicData.volume = queue.volume !== undefined ? queue.volume : 100;
                musicData.loop = queue.loop || 'none';
                musicData.repeatMode = queue.repeatMode || 'once';
                musicData.repeatCount = queue.repeatCount || 1;
                musicData.currentRepeat = queue.currentRepeat || 0;
                musicData.autoplay = queue.autoplay || false;
                musicData.paused = queue.paused || false;

                // Try to find channel name
                // queue doesn't store channelId? Lavalink might. 
                // We'll leave channelName generic or try to find where bot is
                if (guild && guild.me && guild.me.voice && guild.me.voice.channel) {
                    musicData.channelName = guild.me.voice.channel.name;
                }

                const info = queue.nowPlaying.info;
                let cover = 'https://i.imgur.com/2ce2t5e.png'; // Fallback

                if (info.sourceName === 'youtube' || info.uri.includes('youtube')) {
                    cover = `https://img.youtube.com/vi/${info.identifier}/maxresdefault.jpg`;
                } else if (info.artworkUrl) {
                    cover = info.artworkUrl;
                }

                musicData.nowPlaying = {
                    title: info.title,
                    author: info.author,
                    cover: cover,
                    url: info.uri
                };

                musicData.duration = info.length;
                musicData.position = queue.position || 0;

                // Adjust position estimate (only advance if not paused)
                if (queue.lastUpdate && !queue.paused) {
                    const diff = Date.now() - queue.lastUpdate;
                    musicData.position += diff;
                    if (musicData.position > musicData.duration) musicData.position = musicData.duration;
                }

                musicData.queue = queue.songs.map(song => ({
                    title: song.info.title,
                    author: song.info.author,
                    uri: song.info.uri,
                    cover: getCover(song.info)
                }));
                musicData.queueCount = queue.songs.length;
                break;
            }
        }

        if (!musicData.isPlaying) {
            for (const [id, guild] of client.guilds.cache) {
                if (guild.me && guild.me.voice && guild.me.voice.channelId) {
                    musicData.activeGuildId = id;
                    musicData.isConnectedToVoice = true;
                    musicData.guildName = guild.name;
                    musicData.guildIcon = guild.iconURL ? guild.iconURL({ dynamic: true, size: 128 }) : null;
                    if (guild.me.voice.channel) musicData.channelName = guild.me.voice.channel.name;
                    break;
                }
            }
        }

        res.json(musicData);
    });

    app.post('/api/music/stop', async (req, res) => {
        try {
            const queues = client.queueManager ? client.queueManager.getAll() : new Map();
            let stopped = false;

            for (const [guildId, queue] of queues) {
                if (queue.nowPlaying) {
                    if (client.lavalink) {
                        await client.lavalink.destroyPlayer(guildId);
                    }
                    client.queueManager.delete(guildId);

                    // Try to disconnect from voice
                    const { getVoiceConnection } = require('@discordjs/voice');
                    const connection = getVoiceConnection(guildId);
                    if (connection) {
                        connection.destroy();
                    }

                    stopped = true;
                }
            }

            if (stopped) {
                res.json({ success: true, message: 'Music stopped' });
            } else {
                res.json({ success: false, message: 'No music is playing' });
            }
        } catch (error) {
            console.error('Error stopping music:', error);
            res.json({ success: false, message: error.message });
        }
    });

    app.post('/api/music/skip', async (req, res) => {
        try {
            const queues = client.queueManager ? client.queueManager.getAll() : new Map();
            for (const [guildId, queue] of queues) {
                if (queue.nowPlaying) {
                    if (queue.autoplay && queue.songs.length < 5) await client.queueManager.fillAutoplayQueue(client, guildId);
                    const nextSong = client.queueManager.getNext(guildId);

                    if (!nextSong) {
                        if (client.lavalink) await client.lavalink.destroyPlayer(guildId);
                        client.queueManager.delete(guildId);
                    } else {
                        if (queue.nowPlaying) queue.history.push(queue.nowPlaying);
                        queue.nowPlaying = nextSong;
                        queue.position = 0;
                        queue.lastUpdate = Date.now();
                        await client.lavalink.updatePlayer(guildId, nextSong, client.lavalinkVoiceStates[guildId] || {});
                    }
                    return res.json({ success: true });
                }
            }
            res.json({ success: false, message: 'No music playing' });
        } catch (e) { console.error(e); res.json({ success: false }); }
    });

    app.post('/api/music/previous', async (req, res) => {
        try {
            const queues = client.queueManager ? client.queueManager.getAll() : new Map();
            for (const [guildId, queue] of queues) {
                if (queue.nowPlaying && queue.history.length > 0) {
                    const prev = queue.history.pop();
                    queue.songs.unshift(queue.nowPlaying);
                    queue.nowPlaying = prev;
                    queue.position = 0;
                    queue.lastUpdate = Date.now();
                    await client.lavalink.updatePlayer(guildId, prev, client.lavalinkVoiceStates[guildId] || {});
                    return res.json({ success: true });
                }
            }
            res.json({ success: false, message: 'No previous song' });
        } catch (e) { console.error(e); res.json({ success: false }); }
    });

    app.post('/api/music/volume', async (req, res) => {
        const { guildId, volume } = req.body;
        try {
            const queue = client.queueManager ? client.queueManager.get(guildId) : null;
            if (queue && client.lavalink) {
                const vol = parseInt(volume);
                // Extended volume range: 0 - 5000% (5x louder than before)
                if (!isNaN(vol) && vol >= 0 && vol <= 5000) {
                    queue.volume = vol;
                    await client.lavalink.updatePlayerProperties(guildId, { volume: vol });
                    return res.json({ success: true, volume: vol });
                }
            }
            res.json({ success: false, message: 'No active player or invalid volume (0-5000)' });
        } catch (e) {
            console.error(e);
            res.status(500).json({ success: false, error: e.message });
        }
    });

    // Pause / Resume endpoint — supports Manual playback mode for custom file player
    app.post('/api/music/pause', async (req, res) => {
        const { guildId, pause } = req.body;
        try {
            const queue = client.queueManager ? client.queueManager.get(guildId) : null;
            if (queue && client.lavalink) {
                const shouldPause = pause === true || pause === 'true';
                queue.paused = shouldPause;
                await client.lavalink.updatePlayerProperties(guildId, { paused: shouldPause });
                if (shouldPause) {
                    queue.lastUpdate = Date.now(); // Freeze position
                } else {
                    queue.lastUpdate = Date.now(); // Resume position counter
                }
                return res.json({ success: true, paused: shouldPause });
            }
            res.json({ success: false, message: 'No active player' });
        } catch (e) {
            console.error(e);
            res.status(500).json({ success: false, error: e.message });
        }
    });

    app.post('/api/music/loop', async (req, res) => {
        const { guildId, mode, count } = req.body;
        try {
            const queue = client.queueManager ? client.queueManager.get(guildId) : null;
            if (queue && client.lavalink) {
                // New explicit mode argument
                if (mode && ['once', 'loop', 'queue', 'repeatN'].includes(mode)) {
                    queue.repeatMode = mode;
                    // Also sync legacy loop field for compatibility
                    if (mode === 'loop') queue.loop = 'track';
                    else if (mode === 'queue') queue.loop = 'queue';
                    else queue.loop = 'none';

                    if (mode === 'repeatN') {
                        const n = parseInt(count);
                        queue.repeatCount = (!isNaN(n) && n >= 1 && n <= 100) ? n : 1;
                        queue.currentRepeat = 0; // reset counter when mode changes
                    } else {
                        queue.repeatCount = 1;
                        queue.currentRepeat = 0;
                    }
                } else {
                    // Legacy behavior: cycle none -> track -> queue -> none
                    if (queue.repeatMode === 'once' || !queue.repeatMode) {
                        queue.repeatMode = 'loop';
                        queue.loop = 'track';
                    } else if (queue.repeatMode === 'loop') {
                        queue.repeatMode = 'queue';
                        queue.loop = 'queue';
                    } else if (queue.repeatMode === 'queue') {
                        queue.repeatMode = 'once';
                        queue.loop = 'none';
                    } else {
                        queue.repeatMode = 'once';
                        queue.loop = 'none';
                    }
                    queue.currentRepeat = 0;
                }
                return res.json({
                    success: true,
                    repeatMode: queue.repeatMode,
                    repeatCount: queue.repeatCount,
                    currentRepeat: queue.currentRepeat,
                    loop: queue.loop
                });
            }
            res.json({ success: false, message: 'No active player' });
        } catch (e) {
            console.error(e);
            res.status(500).json({ success: false, error: e.message });
        }
    });

    app.post('/api/music/autoplay', async (req, res) => {
        const { guildId } = req.body;
        try {
            const queue = client.queueManager ? client.queueManager.get(guildId) : null;
            if (queue && client.lavalink) {
                queue.autoplay = !queue.autoplay;
                if (queue.autoplay) {
                    await client.queueManager.fillAutoplayQueue(client, guildId);
                }
                return res.json({ success: true, autoplay: queue.autoplay });
            }
            res.json({ success: false, message: 'No active player' });
        } catch (e) {
            console.error(e);
            res.status(500).json({ success: false, error: e.message });
        }
    });

    app.post('/api/music/seek', async (req, res) => {
        const { guildId, amount } = req.body;
        try {
            const queue = client.queueManager ? client.queueManager.get(guildId) : null;
            if (queue && client.lavalink && queue.nowPlaying) {
                let newPosition = queue.position + amount;

                if (newPosition < 0) newPosition = 0;
                if (newPosition > queue.nowPlaying.info.length) {
                    newPosition = queue.nowPlaying.info.length - 1000;
                    if (newPosition < 0) newPosition = 0;
                }

                await client.lavalink.updatePlayerProperties(guildId, { position: newPosition });
                queue.position = newPosition;
                queue.lastUpdate = Date.now();
                return res.json({ success: true, position: newPosition });
            }
            res.json({ success: false, message: 'No active player' });
        } catch (e) {
            console.error(e);
            res.status(500).json({ success: false, error: e.message });
        }
    });

    // fs and path already required at the top

    app.get('/api/music/playlists', (req, res) => {
        try {
            const pltPath = path.join(__dirname, '../data/playlists.json');
            if (fs.existsSync(pltPath)) {
                const data = JSON.parse(fs.readFileSync(pltPath, 'utf8'));
                res.json({ success: true, playlists: Object.keys(data) });
            } else {
                res.json({ success: true, playlists: [] });
            }
        } catch (e) {
            res.json({ success: false, error: e.message });
        }
    });

    app.post('/api/music/playlist/load', async (req, res) => {
        const { guildId, name } = req.body;
        try {
            const pltPath = path.join(__dirname, '../data/playlists.json');
            if (!fs.existsSync(pltPath)) return res.json({ success: false, message: 'No playlists found' });

            const data = JSON.parse(fs.readFileSync(pltPath, 'utf8'));
            const playlist = data[name];
            if (!playlist || playlist.length === 0) return res.json({ success: false, message: 'Playlist not found or empty' });

            const voiceState = client.lavalinkVoiceStates ? client.lavalinkVoiceStates[guildId] : null;
            if (!voiceState || !voiceState.token) {
                return res.json({ success: false, message: 'Bot not connected to voice in this server' });
            }

            let queue = client.queueManager ? client.queueManager.get(guildId) : null;
            if (!queue) {
                queue = client.queueManager.create(guildId);
            }

            let added = 0;
            for (const song of playlist) {
                try {
                    const lRes = await client.lavalink.loadTracks(song.uri);
                    let trackToLoad;

                    if (lRes.loadType === 'track') trackToLoad = lRes.data;
                    else if (lRes.loadType === 'playlist') trackToLoad = lRes.data.tracks[0];
                    else if (lRes.loadType === 'search') trackToLoad = lRes.data[0];

                    if (trackToLoad) {
                        client.queueManager.addSong(guildId, trackToLoad);
                        added++;
                    }
                } catch (e) {
                    console.error('Error loading fav track:', e);
                }
            }

            if (added > 0 && !queue.nowPlaying && client.queueManager) {
                const nextSong = client.queueManager.getNext(guildId);
                if (nextSong) {
                    queue.nowPlaying = nextSong;
                    await client.lavalink.updatePlayer(guildId, nextSong, voiceState, {
                        volume: queue.volume,
                        filters: queue.filters
                    });
                }
            }

            if (queue && queue.autoplay && queue.songs.length < 5) {
                await client.queueManager.fillAutoplayQueue(client, guildId);
            }

            res.json({ success: true, added });
        } catch (e) {
            console.error('Playlist load API error:', e);
            res.json({ success: false, message: e.message });
        }
    });




    app.get('/api/discord/guilds', (req, res) => {
        try {
            const guilds = client.guilds.cache.map(g => ({ id: g.id, name: g.name, icon: g.iconURL() }));
            res.json(guilds);
        } catch (e) { res.json([]); }
    });

    app.get('/api/discord/channels/:guildId', (req, res) => {
        try {
            const guild = client.guilds.cache.get(req.params.guildId);
            if (!guild) return res.json([]);
            const channels = guild.channels.cache
                .filter(c => c.type === 'GUILD_VOICE' || c.type === 'GUILD_STAGE_VOICE')
                .map(c => ({ id: c.id, name: c.name }));
            res.json(channels);
        } catch (e) { res.json([]); }
    });

    app.post('/api/music/join', async (req, res) => {
        const { guildId, channelId } = req.body;
        try {
            const payload = { op: 4, d: { guild_id: guildId, channel_id: channelId, self_mute: false, self_deaf: false } };
            if (client.ws && client.ws.shards) client.ws.shards.get(0).send(payload);
            else client.ws.broadcast(payload);
            res.json({ success: true });
        } catch (e) { console.error(e); res.json({ success: false }); }
    });

    app.post('/api/music/leave', async (req, res) => {
        const { guildId } = req.body;
        try {
            client.queueManager.delete(guildId);
            if (client.lavalink) await client.lavalink.destroyPlayer(guildId);

            const payload = { op: 4, d: { guild_id: guildId, channel_id: null } };
            if (client.ws && client.ws.shards) client.ws.shards.get(0).send(payload);
            else client.ws.broadcast(payload);

            res.json({ success: true });
        } catch (e) { console.error(e); res.json({ success: false }); }
    });

    app.post('/api/music/play', async (req, res) => {
        const { guildId, query } = req.body;
        if (!guildId || !query) return res.json({ success: false, message: 'Missing args' });

        try {
            const { playLogic } = require('../commands/play');
            const result = await playLogic(client, guildId, query);
            res.json(result);
        } catch (e) { console.error(e); res.json({ success: false, message: e.message }); }
    });

    // --- CUSTOM FILE UPLOAD (Voice) ---
    // Uploads an MP3/MP4 file to a public host so the remote Lavalink server
    // can stream it. Tries catbox.moe first (permanent), falls back to
    // tmpfiles.org (1-hour expiry, but reliable).
    app.post('/api/voice/upload', express.raw({ type: '*/*', limit: '220mb' }), async (req, res) => {
        try {
            if (!req.body || !req.body.length) {
                return res.json({ success: false, message: 'No file received' });
            }

            const filename = req.headers['x-filename']
                ? decodeURIComponent(req.headers['x-filename'])
                : 'upload.mp3';
            const contentType = req.headers['content-type'] || 'application/octet-stream';

            console.log(`[Voice Upload] Received file: ${filename} (${(req.body.length / 1024 / 1024).toFixed(2)} MB, type: ${contentType})`);

            // --- Strategy 1: catbox.moe (permanent, but may reject some IPs) ---
            try {
                const formData = new FormData();
                formData.append('reqtype', 'fileupload');
                formData.append('fileToUpload', new Blob([req.body], { type: contentType }), filename);

                const catRes = await fetch('https://catbox.moe/user/api.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'User-Agent': 'PROPlus/1.0 (https://github.com/proplus)'
                    }
                });

                if (catRes.ok) {
                    const responseText = (await catRes.text()).trim();
                    if (responseText.startsWith('https://')) {
                        console.log('[Voice Upload] catbox.moe success:', responseText);
                        return res.json({ success: true, url: responseText, host: 'catbox' });
                    }
                    console.log('[Voice Upload] catbox.moe responded non-URL:', responseText, '— falling back to tmpfiles');
                } else {
                    console.log('[Voice Upload] catbox.moe HTTP', catRes.status, '— falling back to tmpfiles');
                }
            } catch (catErr) {
                console.log('[Voice Upload] catbox.moe error:', catErr.message, '— falling back to tmpfiles');
            }

            // --- Strategy 2: tmpfiles.org (1-hour expiry, very reliable) ---
            const formData = new FormData();
            formData.append('file', new Blob([req.body], { type: contentType }), filename);

            const tmpRes = await fetch('https://tmpfiles.org/api/v1/upload', {
                method: 'POST',
                body: formData,
                headers: {
                    'User-Agent': 'PROPlus/1.0 (https://github.com/proplus)'
                }
            });

            if (!tmpRes.ok) {
                const errText = await tmpRes.text();
                console.error('[Voice Upload] tmpfiles.org error:', tmpRes.status, errText);
                return res.json({ success: false, message: `Both file hosts failed. Last error: tmpfiles ${tmpRes.status} ${errText}` });
            }

            const tmpData = await tmpRes.json();
            if (tmpData.status !== 'success' || !tmpData.data || !tmpData.data.url) {
                return res.json({ success: false, message: 'tmpfiles.org did not return a URL' });
            }

            // tmpfiles.org returns a viewer URL like https://tmpfiles.org/<id>/<filename>
            // We need to fetch that page and extract the actual direct download URL
            // from the <a class="download" href="..."> tag.
            const viewerUrl = tmpData.data.url;
            console.log('[Voice Upload] tmpfiles.org viewer URL:', viewerUrl);

            const viewerRes = await fetch(viewerUrl, {
                headers: { 'User-Agent': 'PROPlus/1.0 (https://github.com/proplus)' }
            });
            const html = await viewerRes.text();

            // Extract direct download URL
            const match = html.match(/<a[^>]*class="download"[^>]*href="([^"]+)"/i);
            if (match && match[1]) {
                const directUrl = match[1];
                console.log('[Voice Upload] tmpfiles.org direct URL:', directUrl);
                return res.json({ success: true, url: directUrl, host: 'tmpfiles', expires: '1 hour' });
            }

            // Fallback: try the simple /dl/<id>/<filename> pattern (won't be a direct file
            // but at least accessible). Lavalink might still be able to follow it.
            const simpleDirect = viewerUrl.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
            console.log('[Voice Upload] Could not extract direct URL, returning simple pattern:', simpleDirect);
            return res.json({ success: true, url: simpleDirect, host: 'tmpfiles', expires: '1 hour', warning: 'Direct URL extraction failed' });
        } catch (e) {
            console.error('[Voice Upload] Error:', e);
            return res.json({ success: false, message: e.message });
        }
    });

    // --- SERVER CLONER ROUTES ---

    // In-memory state for Cloner
    const clonerState = {
        instance: null,
        isRunning: false,
        logs: [],
        sourceId: '',
        targetId: '',
        stats: {}
    };

    app.get('/server-cloner', (req, res) => {
        if (!client.user) return res.send('Bot loading...');
        res.render('server-cloner', {
            user: client.user,
            page: 'cloner'
        });
    });

    app.get('/api/cloner/status', (req, res) => {
        res.json({
            isRunning: clonerState.isRunning,
            logs: clonerState.logs,
            stats: clonerState.stats
        });
    });

    app.post('/api/cloner/fetch', async (req, res) => {
        const { guildId } = req.body;
        try {
            const guild = client.guilds.cache.get(guildId);
            if (!guild) return res.json({ success: false, message: 'Guild not found (Bot must be a member)' });

            const member = await guild.members.fetch(client.user.id).catch(() => null);
            const isAdmin = member ? member.permissions.has('ADMINISTRATOR') : false;

            res.json({
                success: true,
                name: guild.name,
                icon: guild.iconURL({ dynamic: true, size: 128 }),
                isAdmin: isAdmin,
                isOwner: guild.ownerId === client.user.id
            });
        } catch (e) { res.json({ success: false, message: e.message }); }
    });

    app.post('/api/cloner/start', async (req, res) => {
        if (clonerState.isRunning) return res.json({ success: false, message: 'Already running' });

        const { sourceId, targetId, options } = req.body;

        clonerState.isRunning = true;
        clonerState.logs = [];
        clonerState.stats = {};
        clonerState.sourceId = sourceId;
        clonerState.targetId = targetId;

        clonerState.logs.push(`[${new Date().toLocaleTimeString()}] Request received. Initializing...`);

        const ServerCloner = require('../cloner/ServerCloner');
        const cloner = new ServerCloner(client, (msg) => {
            clonerState.logs.push(`[${new Date().toLocaleTimeString()}] ${msg}`);
            if (clonerState.logs.length > 500) clonerState.logs.shift();
        });

        clonerState.instance = cloner;

        // Run in background
        cloner.cloneServer(sourceId, targetId, options)
            .then(stats => {
                clonerState.stats = stats;
                clonerState.isRunning = false;
                clonerState.instance = null;
                clonerState.logs.push(`[${new Date().toLocaleTimeString()}] Process completed successfully.`);
            })
            .catch(err => {
                clonerState.isRunning = false;
                clonerState.instance = null;
                // If stopped manually, we might have already logged "stopped by user" in cloner, but let's be safe
                if (err.message !== 'Cloning stopped by user.') { // Assuming standard error if any
                    clonerState.logs.push(`[${new Date().toLocaleTimeString()}] Error: ${err.message}`);
                }
            });

        res.json({ success: true });
    });

    app.post('/api/cloner/stop', (req, res) => {
        if (clonerState.instance) {
            clonerState.instance.stop();
            // Logging is handled inside Cloner stop() -> log()
            res.json({ success: true, message: 'Stop signal sent.' });
        } else {
            res.json({ success: false, message: 'No active process' });
        }
    });

    // ============================
    // --- SPAMMER & DM PURGE ---
    // ============================
    // In-memory state for Spammer
    const spammerState = {
        isRunning: false,
        mode: null,        // 'message' or 'call'
        victimId: null,
        count: 0,
        completed: 0,
        failed: 0,
        delayMs: 0,
        startedAt: 0,
        message: '',
        intervalId: null,
        logs: [],
        stopRequested: false
    };

    function logSpammer(msg) {
        const time = new Date().toLocaleTimeString();
        const line = `[${time}] ${msg}`;
        spammerState.logs.push(line);
        if (spammerState.logs.length > 500) spammerState.logs.shift();
        console.log(`[Spammer] ${msg}`);
    }

    function resetSpammerState() {
        if (spammerState.intervalId) {
            clearInterval(spammerState.intervalId);
            spammerState.intervalId = null;
        }
        spammerState.isRunning = false;
        spammerState.mode = null;
        spammerState.victimId = null;
        spammerState.count = 0;
        spammerState.completed = 0;
        spammerState.failed = 0;
        spammerState.delayMs = 0;
        spammerState.startedAt = 0;
        spammerState.message = '';
        spammerState.intervalId = null;
        spammerState.stopRequested = false;
    }

    app.get('/api/spammer/status', (req, res) => {
        res.json({
            isRunning: spammerState.isRunning,
            mode: spammerState.mode,
            victimId: spammerState.victimId,
            count: spammerState.count,
            completed: spammerState.completed,
            failed: spammerState.failed,
            delayMs: spammerState.delayMs,
            startedAt: spammerState.startedAt,
            message: spammerState.message,
            stopRequested: spammerState.stopRequested,
            logs: spammerState.logs
        });
    });

    app.post('/api/spammer/start', async (req, res) => {
        const { mode, victimId, count, ms, sec, message } = req.body;

        // Validate inputs
        if (!mode || !['message', 'call'].includes(mode)) {
            return res.json({ success: false, message: 'Mode must be "message" or "call"' });
        }
        if (!victimId || !/^\d{17,20}$/.test(String(victimId))) {
            return res.json({ success: false, message: 'Invalid victim user ID' });
        }
        const totalMs = (parseInt(ms) || 0) + (parseInt(sec) || 0) * 1000;
        if (totalMs < 0) {
            return res.json({ success: false, message: 'Time cannot be negative' });
        }
        const total = parseInt(count);
        if (isNaN(total) || total < 1) {
            return res.json({ success: false, message: 'Count must be a positive number' });
        }

        if (spammerState.isRunning) {
            return res.json({ success: false, message: 'Spammer is already running. Stop it first.' });
        }

        // Reset state and start
        resetSpammerState();
        spammerState.isRunning = true;
        spammerState.mode = mode;
        spammerState.victimId = String(victimId);
        spammerState.count = total;
        spammerState.delayMs = totalMs;
        spammerState.startedAt = Date.now();
        spammerState.message = (message || '').toString();

        logSpammer(`Started ${mode.toUpperCase()} spam — victim=${victimId}, count=${total}, delay=${totalMs}ms`);

        res.json({ success: true, message: 'Spammer started' });

        // Fetch victim once (for DM channel creation)
        let dmChannel = null;
        try {
            const user = await client.users.fetch(spammerState.victimId).catch(() => null);
            if (!user) {
                logSpammer(`Error: Cannot fetch victim user ${spammerState.victimId}`);
                resetSpammerState();
                return;
            }
            dmChannel = await user.createDM().catch(() => null);
            if (!dmChannel) {
                logSpammer(`Error: Cannot create DM channel with victim ${spammerState.victimId}`);
                resetSpammerState();
                return;
            }
        } catch (e) {
            logSpammer(`Init error: ${e.message}`);
            resetSpammerState();
            return;
        }

        let processed = 0;

        // Run a tight loop — for very small delays (e.g. 1ms), setInterval
        // is the most reliable approach. We let Discord rate-limit naturally
        // via the selfbot lib's internal queue.
        const tick = async () => {
            if (!spammerState.isRunning || spammerState.stopRequested) {
                if (spammerState.intervalId) {
                    clearInterval(spammerState.intervalId);
                    spammerState.intervalId = null;
                }
                logSpammer(`Stopped. Completed ${spammerState.completed}/${spammerState.count}, failed ${spammerState.failed}.`);
                resetSpammerState();
                return;
            }

            if (processed >= spammerState.count) {
                if (spammerState.intervalId) {
                    clearInterval(spammerState.intervalId);
                    spammerState.intervalId = null;
                }
                logSpammer(`Done. Completed ${spammerState.completed}/${spammerState.count}, failed ${spammerState.failed}.`);
                resetSpammerState();
                return;
            }

            processed++;
            try {
                if (spammerState.mode === 'message') {
                    // Send DM message
                    const content = spammerState.message || `Spam #${processed}`;
                    await dmChannel.send(content);
                    spammerState.completed++;
                    if (processed <= 5 || processed % 10 === 0) {
                        logSpammer(`Message ${processed}/${spammerState.count} sent`);
                    }
                } else if (spammerState.mode === 'call') {
                    // Start call, end immediately
                    try {
                        // Start the call via REST: POST /channels/{id}/call with recipients
                        await client.api.channels(dmChannel.id).call.post({
                            data: { recipients: [spammerState.victimId] }
                        }).catch(() => { });
                        // End the call immediately by leaving it
                        await client.api.channels(dmChannel.id).call.delete().catch(() => { });
                        spammerState.completed++;
                        if (processed <= 5 || processed % 10 === 0) {
                            logSpammer(`Call ${processed}/${spammerState.count} (start + instant end)`);
                        }
                    } catch (callErr) {
                        spammerState.failed++;
                        if (processed <= 3) logSpammer(`Call error: ${callErr.message}`);
                    }
                }
            } catch (err) {
                spammerState.failed++;
                if (processed <= 3 || processed % 20 === 0) {
                    logSpammer(`Error on #${processed}: ${err.message}`);
                }
            }
        };

        // For 0ms or 1ms delays, use setInterval with delay 0 (which is ~4ms in practice).
        // For larger delays, use the actual delay.
        const intervalMs = Math.max(0, spammerState.delayMs);
        spammerState.intervalId = setInterval(tick, intervalMs);

        // Safety: also run immediately for first iteration when delay is very small
        if (intervalMs <= 5) {
            tick();
        }
    });

    app.post('/api/spammer/stop', (req, res) => {
        if (!spammerState.isRunning) {
            return res.json({ success: false, message: 'Spammer is not running' });
        }
        spammerState.stopRequested = true;
        logSpammer('Stop requested by user.');
        res.json({ success: true, message: 'Stop requested.' });
    });

    app.post('/api/spammer/clear-logs', (req, res) => {
        spammerState.logs = [];
        res.json({ success: true });
    });

    // ============================
    // --- DM PURGE ---
    // ============================
    // Deletes YOUR OWN messages in the DM channel with a victim user.
    // count = -1 means "infinity" → deletes ALL your messages in that DM.
    const dmPurgeState = {
        isRunning: false,
        victimId: null,
        count: 0,
        deleted: 0,
        failed: 0,
        logs: [],
        stopRequested: false,
        mode: 'count'  // 'count' or 'all'
    };

    function logPurge(msg) {
        const time = new Date().toLocaleTimeString();
        const line = `[${time}] ${msg}`;
        dmPurgeState.logs.push(line);
        if (dmPurgeState.logs.length > 500) dmPurgeState.logs.shift();
        console.log(`[DM Purge] ${msg}`);
    }

    app.get('/api/spammer/purge/status', (req, res) => {
        res.json({
            isRunning: dmPurgeState.isRunning,
            victimId: dmPurgeState.victimId,
            count: dmPurgeState.count,
            deleted: dmPurgeState.deleted,
            failed: dmPurgeState.failed,
            mode: dmPurgeState.mode,
            stopRequested: dmPurgeState.stopRequested,
            logs: dmPurgeState.logs
        });
    });

    app.post('/api/spammer/purge/start', async (req, res) => {
        const { victimId, count } = req.body;

        if (!victimId || !/^\d{17,20}$/.test(String(victimId))) {
            return res.json({ success: false, message: 'Invalid victim user ID' });
        }

        const countNum = parseInt(count);
        if (isNaN(countNum)) {
            return res.json({ success: false, message: 'Count must be a number (-1 for infinity, or positive integer)' });
        }
        if (countNum === 0) {
            return res.json({ success: false, message: 'Count 0 does nothing. Use -1 for all messages or a positive number.' });
        }
        if (countNum < -1) {
            return res.json({ success: false, message: 'Count must be -1 (infinity) or a positive number' });
        }

        if (dmPurgeState.isRunning) {
            return res.json({ success: false, message: 'A DM purge is already running. Stop it first.' });
        }

        // Reset
        dmPurgeState.isRunning = true;
        dmPurgeState.victimId = String(victimId);
        dmPurgeState.count = countNum;
        dmPurgeState.deleted = 0;
        dmPurgeState.failed = 0;
        dmPurgeState.stopRequested = false;
        dmPurgeState.mode = countNum === -1 ? 'all' : 'count';
        dmPurgeState.logs = [];

        const targetLabel = countNum === -1 ? 'ALL messages (infinity)' : `${countNum} messages`;
        logPurge(`Starting DM purge — victim=${victimId}, target=${targetLabel}`);

        res.json({ success: true, message: 'DM purge started' });

        // Run in background
        (async () => {
            try {
                const user = await client.users.fetch(dmPurgeState.victimId).catch(() => null);
                if (!user) {
                    logPurge(`Error: Cannot fetch victim user ${dmPurgeState.victimId}`);
                    dmPurgeState.isRunning = false;
                    return;
                }
                const dmCh = await user.createDM().catch(() => null);
                if (!dmCh) {
                    logPurge(`Error: Cannot open DM channel with ${dmPurgeState.victimId}`);
                    dmPurgeState.isRunning = false;
                    return;
                }

                const targetCount = dmPurgeState.count;
                const isInfinite = targetCount === -1;
                let totalToDelete = isInfinite ? Infinity : targetCount;
                let lastMessageId = null;
                let consecutiveEmpty = 0;

                while (dmPurgeState.isRunning && !dmPurgeState.stopRequested && dmPurgeState.deleted < totalToDelete) {
                    try {
                        const fetchOpts = { limit: 100 };
                        if (lastMessageId) fetchOpts.before = lastMessageId;
                        const messages = await dmCh.messages.fetch(fetchOpts);

                        if (messages.size === 0) {
                            consecutiveEmpty++;
                            if (consecutiveEmpty >= 2 || isInfinite) {
                                logPurge('No more messages to fetch.');
                                break;
                            }
                            continue;
                        }
                        consecutiveEmpty = 0;

                        // Filter to messages authored by us
                        const myMessages = messages.filter(m => m.author && m.author.id === client.user.id);

                        if (myMessages.size === 0) {
                            // No own messages in this batch — keep paginating
                            lastMessageId = messages.last().id;
                            continue;
                        }

                        for (const [, msg] of myMessages) {
                            if (dmPurgeState.stopRequested) break;
                            if (!isInfinite && dmPurgeState.deleted >= targetCount) break;

                            try {
                                await msg.delete();
                                dmPurgeState.deleted++;
                                if (dmPurgeState.deleted <= 5 || dmPurgeState.deleted % 25 === 0) {
                                    logPurge(`Deleted ${dmPurgeState.deleted}${isInfinite ? '' : '/' + targetCount}`);
                                }
                                // Discord rate limit safety — 600ms between deletes
                                await new Promise(r => setTimeout(r, 600));
                            } catch (delErr) {
                                dmPurgeState.failed++;
                                if (dmPurgeState.failed <= 3) logPurge(`Delete error: ${delErr.message}`);
                                await new Promise(r => setTimeout(r, 1000));
                            }
                        }

                        // Update lastMessageId for pagination
                        lastMessageId = messages.last().id;

                        // If not infinite and we hit target, break
                        if (!isInfinite && dmPurgeState.deleted >= targetCount) break;
                    } catch (fetchErr) {
                        logPurge(`Fetch error: ${fetchErr.message}`);
                        await new Promise(r => setTimeout(r, 2000));
                    }
                }

                logPurge(`Purge complete. Deleted ${dmPurgeState.deleted}, failed ${dmPurgeState.failed}.`);
            } catch (e) {
                logPurge(`Fatal error: ${e.message}`);
            } finally {
                dmPurgeState.isRunning = false;
            }
        })();
    });

    app.post('/api/spammer/purge/stop', (req, res) => {
        if (!dmPurgeState.isRunning) {
            return res.json({ success: false, message: 'No DM purge running' });
        }
        dmPurgeState.stopRequested = true;
        logPurge('Stop requested by user.');
        res.json({ success: true, message: 'Stop requested.' });
    });

    app.post('/api/spammer/purge/clear-logs', (req, res) => {
        dmPurgeState.logs = [];
        res.json({ success: true });
    });

    app.listen(port, () => {
        console.log(`Dashboard is running on http://localhost:${port}`);
    });
};
